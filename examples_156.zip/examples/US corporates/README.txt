To run this example,

cd "US corporates"
fia64 -c ss.cnf

