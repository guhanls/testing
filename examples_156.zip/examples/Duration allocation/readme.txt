This directory contains sample data for a simple duration allocation analysis. No yield curve data is provided, so the only source of yields is the YTM field in the portfolio and benchmark files. As a result, no curve decomposition is available and all curve return is allocated to 'Capital'.

To simplify this example, all returns are assumed due to yield changes and there is no carry or credit return. 

Results are identical to the worked example in 'Duration allocation workbook' which describes the calculation. Refer also to Chapter 14 in 'Mastering attribution in finance', Andrew Colin.