This directory contains sample data for a multi-level Brinson analysis without any yield curve data. 

Raw data was taken from the enclosed Levecq paper 'An exposure based attribution model for balanced portfolios'. Results agree exactly with the paper. 

To run the example,

cd "Multilevel Brinson"
fia64 -c levecq.cnf
