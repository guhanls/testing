// Load test for FIA/Java

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

import com.flametree.attribution.fia_java;
import com.flametree.attribution.stringmatrix;
import com.flametree.attribution.stringvector;

public class load_test {

    //-------------------------------------------------------------------------

    public static stringvector ConvertStringArrayToStringVector( String[] v )
    {
        stringvector v_data = new stringvector( v.length );

        for ( int i = 0; i < v.length; i++ )
            v_data.set ( i, v[i] );
        return v_data;
    }

    //--------------------------------------------------------------------------
    // Build dummy portfolio AS A VECTOR

    public static stringvector BuildPortfolio( String p_id, int n_days, int n_securities )
    {
        stringvector p_data = new stringvector( n_days * n_securities * 6 );

        // Build date array
        SimpleDateFormat formatter = new SimpleDateFormat( "yyyy-MM-dd" );
        GregorianCalendar cal = new GregorianCalendar();
        int year = 2021;

        cal.set( Calendar.YEAR, year );
        if ( cal.isLeapYear( year ) )
        {
            n_days++;
        }

        Random rand = new Random( System.currentTimeMillis() );

        for( int d = 1; d <= n_days; d++ )
        {
            cal.set( Calendar.DAY_OF_YEAR, d );
            Date date = cal.getTime();

            for ( int s = 0; s < n_securities; s++ )
            {
                double double_random = 0.01 * ( 1 - 2 * rand.nextDouble() );

                int index = 6 * ( ( d - 1 ) * n_securities + s );
                p_data.set ( index + 0, formatter.format( date ) );
                p_data.set ( index + 1, p_id );
                p_data.set ( index + 2, "S" + String.format( "%03d", s ) );
                p_data.set ( index + 3, String.valueOf( 1.0 / n_securities ) );
                p_data.set ( index + 4, String.valueOf( double_random ) );
                p_data.set ( index + 5, String.valueOf ( double_random ) );
            }
        }
        return p_data;
    }

    //--------------------------------------------------------------------------
    // Build dummy security master AS A VECTOR

    public static stringvector BuildSecurityMaster( int n_securities )
    {
        stringvector s_data = new stringvector( n_securities * 9 );

        for ( int s = 0; s < n_securities; s++ )
        {
            s_data.set ( ( s * 9 ) + 0, "S" + String.format( "%03d", s ) );
            s_data.set ( ( s * 9 ) + 1, "S" + String.format( "%03d", s ) );
            s_data.set ( ( s * 9 ) + 2, "SECTOR1=SEC" + s % 4 + "|SECTOR2=SEC" + s % 3 );
            s_data.set ( ( s * 9 ) + 3, "" );
            s_data.set ( ( s * 9 ) + 4, "FT_CASH" );
            s_data.set ( ( s * 9 ) + 5, "" );
            s_data.set ( ( s * 9 ) + 6, "" );
            s_data.set ( ( s * 9 ) + 7, "" );
            s_data.set ( ( s * 9 ) + 8, "AUD" );
        }
        return s_data;
    }

    //-------------------------------------------------------------------------

    public static void main( String argv[] ) {

        System.loadLibrary( "fia_java" );
        fia_java.FIA_init();

        String [] report_sectors = {"SECTOR1,SECURITY"};

        stringvector r_data = ConvertStringArrayToStringVector( report_sectors );
        fia_java.FIA_set_vector_string ( FIA_API_constants.FT_STRING_REPORT_SECTORS, r_data );

        // Initialize all FIA variables
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_CARRY_DECOMPOSITION, "NONE" );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_SOVEREIGN_CURVE_DECOMPOSITION, "NONE" );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_RESIDUAL_RETURN_LABEL, "Stock selection" );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_CSV_REPORT, false );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_XLS_REPORT, true );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_DATE_FORMAT, "%Y-%m-%d" );
        fia_java.FIA_set_integer ( FIA_API_constants.FT_INT_BATCH_ID, 999 );
        fia_java.FIA_set_integer ( FIA_API_constants.FT_INT_N_CORES, -1 );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_SUMMARY_ATTRIBUTION_REPORT, false );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_INTERACTIVE_ATTRIBUTION_REPORT, true );

        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_BRINSON_ALLOCATION_SECTORS, "SECTOR2,SECTOR1" );

        int n_days = 300;
        int n_securities = 100;

        int SECURITY_WIDTH = 9;
        int WEIGHT_RETURN_WIDTH = 6;

        stringvector p_test;
        stringvector b_test;
        stringvector s_test;

        for ( int i = 0; i < 50; i++ )
        {
            System.out.println ( i );
            p_test = BuildPortfolio( "PORTFOLIO", n_days, n_securities );
            b_test = BuildPortfolio( "BENCHMARK", n_days, n_securities );
            s_test = BuildSecurityMaster( n_securities );

            fia_java.FIA_set_structure( FIA_API_constants.FT_MATRIX_PORTFOLIO, p_test, n_days * n_securities, WEIGHT_RETURN_WIDTH );
            fia_java.FIA_set_structure( FIA_API_constants.FT_MATRIX_BENCHMARK, b_test, n_days * n_securities, WEIGHT_RETURN_WIDTH  );
            fia_java.FIA_set_structure( FIA_API_constants.FT_MATRIX_SECURITY, s_test, n_securities, SECURITY_WIDTH );

            fia_java.FIA_run();

            p_test.delete();
            b_test.delete();
            s_test.delete();
        }

    }
}
