// Extended demo code for FIA/Java
// Shows initialisation of all types of variables, exporting results

import com.flametree.attribution.fia_java;
import com.flametree.attribution.stringmatrix;
import com.flametree.attribution.stringvector;

public class demo_java {

    //-------------------------------------------------------------------------

    public static stringvector ConvertStringArrayToStringVector( String[] v )
    {
        stringvector v_data = new stringvector( v.length );

        for ( int i = 0; i < v.length; i++ )
            v_data.set ( i, v[i] );
        return v_data;
    }

    //-------------------------------------------------------------------------

    public static stringmatrix ConvertStringArrayToStringMatrix( String[][] s )
    {
        stringmatrix s_data = new stringmatrix( s.length );

        for ( int i = 0; i < s.length; i++ )
        {
            stringvector s1 = new stringvector ( s[i].length );
            for ( int j = 0; j < s[i].length; j++ )
                s1.set ( j, s[i][j] );
            s_data.set ( i, s1 );
        }

        return s_data;
    }

    //-------------------------------------------------------------------------

    public static void main( String argv[] ) {

        System.loadLibrary( "fia_java" );
        fia_java.FIA_init();
        System.out.println( "Running Flametree version " + fia_java.FIA_get_version() );

        String[][] s =
        {
            {"ZERO_INTEREST_CASH", "ZERO_INTEREST_CASH", "SECURITY_TYPE=CASH", "", "FT_CASH", "", "", "", "AUD", "", "", "", "", "", "", "", ""},
            {"BANK_BILL", "BANK_BILL", "SECURITY_TYPE=BILL", "", "FT_BILL", "", "", "", "AUD", "", "BASE_CURVE", "", "2011-Jan-01", "", "", "", ""},
            {"VANILLA_BOND", "VANILLA_BOND", "SECURITY_TYPE=BOND", "", "FT_BOND_ZERO_CURVE", "", "", "", "AUD", "", "BASE_CURVE|SECTOR_CURVE", "", "2019-Jan-01", "0.04", "2", "", ""},
            {"DELAYED_BOND", "DELAYED_BOND", "SECURITY_TYPE=BOND", "", "FT_BOND_ZERO_CURVE", "", "", "", "AUD", "", "BASE_CURVE", "2015-Jan-01", "2019-Jan-01", "0.05", "2", "", ""},
            {"IL_BOND", "IL_BOND", "SECURITY_TYPE=IL BOND", "", "FT_BOND_ZERO_CURVE", "Inflation(AUD_CPI)", "", "", "AUD", "", "BASE_CURVE", "", "2019-Jan-15", "0.04", "4", "", ""},
            {"FRN", "FRN", "SECURITY_TYPE=FRN", "", "FT_FRN_ZERO_CURVE(MONTHLY_LIBOR)", "", "", "", "AUD", "", "BASE_CURVE", "", "2019-Jan-01", "0.0025", "12", "", ""},
            {"PERTURBATIONAL", "PERTURBATIONAL", "SECURITY_TYPE=BOND", "", "", "", "", "", "AUD", "", "BASE_CURVE|SECTOR_CURVE", "", "2011-Jan-01", "0.05", "2", "", ""},
            {"AMORTIZING_BOND", "AMORTIZING_BOND", "SECURITY_TYPE=BOND", "", "FT_SINKER_ZERO_CURVE", "", "", "", "AUD", "", "BASE_CURVE", "", "2019-Jan-01", "0.05", "4", "", "8.5"},
            {"CDS", "CDS", "SECURITY_TYPE=CDS", "", "FT_CDS", "", "", "", "AUD", "", "BASE_CURVE", "", "2019-Jan-01", "0.04", "12", "", ""}
        };

        String[][] p =
        {
            { "2010-Jan-01", "PTF", "ZERO_INTEREST_CASH",			"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "VANILLA_BOND",					"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "ZERO_INTEREST_CASH",			"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "BANK_BILL",					"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "DELAYED_BOND",					"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "IL_BOND",						"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "FRN",							"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "CDS",							"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "PERTURBATIONAL",				"1.0", "0.0", "0.0", "0.05", "5.0", "0.2" },
            { "2011-Jan-01", "PTF", "AMORTIZING_BOND",				"1.0", "0.0", "0.0", "", "", "" }
        };

        String[][] b =
        {
            { "2010-Jan-01", "PTF", "ZERO_INTEREST_CASH",			"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "VANILLA_BOND",					"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "ZERO_INTEREST_CASH",			"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "BANK_BILL",					"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "DELAYED_BOND",					"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "IL_BOND",						"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "FRN",							"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "CDS",							"1.0", "0.0", "0.0", "", "", "" },
            { "2011-Jan-01", "PTF", "PERTURBATIONAL",				"1.0", "0.0", "0.0", "0.05", "5.0", "0.2" },
            { "2011-Jan-01", "PTF", "AMORTIZING_BOND",				"1.0", "0.0", "0.0", "", "", "" }
        };


        // Set up yield curve data
        String [][] y =
        {
            {"BASE_CURVE", "2010-Jan-01", "0.0",   "0.050"},
            {"BASE_CURVE", "2010-Jan-01", "4.0",   "0.050"},
            {"BASE_CURVE", "2010-Jan-01", "8.0",   "0.050"},
            {"BASE_CURVE", "2011-Jan-01", "0.0",   "0.045"},
            {"BASE_CURVE", "2011-Jan-01", "4.0",   "0.045"},
            {"BASE_CURVE", "2011-Jan-01", "8.0",   "0.045"},
            {"SECTOR_CURVE", "2010-Jan-01", "0.0",  "0.055"},
            {"SECTOR_CURVE", "2010-Jan-01", "4.0",  "0.055"},
            {"SECTOR_CURVE", "2010-Jan-01", "8.0",  "0.055"},
            {"SECTOR_CURVE", "2011-Jan-01", "0.0",  "0.051"},
            {"SECTOR_CURVE", "2011-Jan-01", "4.0",  "0.051"},
            {"SECTOR_CURVE", "2011-Jan-01", "8.0",  "0.051"}
        };

        String[][] index = {
            { "2009-Jun-01", "AUD_CPI", "80.0" },
            { "2009-Jul-01", "AUD_CPI", "80.1" },
            { "2009-Aug-01", "AUD_CPI", "80.2" },
            { "2009-Sep-01", "AUD_CPI", "80.3" },
            { "2009-Oct-01", "AUD_CPI", "80.4" },
            { "2009-Nov-01", "AUD_CPI", "80.5" },
            { "2009-Dec-01", "AUD_CPI", "80.6" },
            { "2009-Jun-01", "MONTHLY_LIBOR", "0.01" },
            { "2009-Jul-01", "MONTHLY_LIBOR", "0.01" },
            { "2009-Aug-01", "MONTHLY_LIBOR", "0.01" },
            { "2009-Sep-01", "MONTHLY_LIBOR", "0.01" },
            { "2009-Oct-01", "MONTHLY_LIBOR", "0.01" },
            { "2009-Nov-01", "MONTHLY_LIBOR", "0.01" },
            { "2009-Dec-01", "MONTHLY_LIBOR", "0.01" }
        };

        String [] report_sectors = {"COUPON,SECURITY", "MATURITY,SECURITY"};

        // Assign statically declared arrays to FIA-readable structures
        stringmatrix s_data = ConvertStringArrayToStringMatrix ( s );
        stringmatrix p_data = ConvertStringArrayToStringMatrix ( p );
        stringmatrix b_data = ConvertStringArrayToStringMatrix ( b );
        stringmatrix y_data = ConvertStringArrayToStringMatrix ( y );
        stringmatrix i_data = ConvertStringArrayToStringMatrix ( index );
        stringvector r_data = ConvertStringArrayToStringVector( report_sectors );

        // Initialize all FIA variables

        fia_java.FIA_set_matrix( FIA_API_constants.FT_MATRIX_PORTFOLIO, p_data );
        fia_java.FIA_set_matrix( FIA_API_constants.FT_MATRIX_BENCHMARK, b_data );
        fia_java.FIA_set_matrix( FIA_API_constants.FT_MATRIX_SECURITY, s_data );
        fia_java.FIA_set_matrix( FIA_API_constants.FT_MATRIX_YIELDCURVE, y_data );
        fia_java.FIA_set_matrix( FIA_API_constants.FT_MATRIX_INDEX, i_data );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_CARRY_DECOMPOSITION, "PULL_TO_PAR" );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_AVERAGE_CURVE_LEVEL, "TRAPEZOIDAL" );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_SOVEREIGN_CURVE_DECOMPOSITION, "STB" );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_CONVEXITY_ATTRIBUTION, true );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_CSV_REPORT, true );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_XLS_REPORT, true );
        fia_java.FIA_set_string ( FIA_API_constants.FT_STRING_DATE_FORMAT, "%Y-%b-%d" );
        fia_java.FIA_set_integer ( FIA_API_constants.FT_INT_BATCH_ID, 999 );
        fia_java.FIA_set_integer ( FIA_API_constants.FT_INT_N_CORES, 1 );
        fia_java.FIA_set_bool ( FIA_API_constants.FT_BOOL_SUMMARY_ATTRIBUTION_REPORT, true );
        fia_java.FIA_set_vector_string ( FIA_API_constants.FT_STRING_REPORT_SECTORS, r_data );

        fia_java.FIA_run();


    }
}
