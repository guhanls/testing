#------------------------------------------------------------------------------
#
# File: sinker.py
#
# Author: Andrew Colin
#
# Description: Simple demo to show how to upload files, run FIA, and download
# results.
#
#------------------------------------------------------------------------------

from fia import *

username = 'NT'
password = 'ff7#7U'

data = {
    "PortfolioFile"                 : "sinker_p.csv",
    "SecurityFile"                  : "sinker_s.csv",
    "YieldCurveFile"                : "sinker_y.csv",
    "DateFormat"                    : "%Y-%b-%d",
    "CarryDecomposition"            : "Aggregated",
    "SovereignCurveDecomposition"   : "STB",
    "BatchID"			    : "0",
    "SummaryAttributionReport"      : "true",
    "InteractiveAttributionReport"  : "true",
    "CSVreport"                     : "false",
    "XLSreport"                     : "true",
    "SmoothingModel"                : "Carino",
    "SingleExcelReportFile"         : "sinker",
    "FileHeaders"                   : "true",    
    "ZipFile"                       : "sinker.zip"
}

print ('Pinging the server to test latency')
LatencyTest()

GetIPAddress()

ListFiles(username, password)

DeleteFile("*", username, password)

# Upload files only once
UploadFile (data['PortfolioFile'],    username, password)
UploadFile (data['SecurityFile'],     username, password)
UploadFile (data['YieldCurveFile'],   username, password)

ListFiles(username, password)

# Run FIA using these parameters and files in filestore
print('Running FIA using JSON settings')
job_id = RunJson (data, username, password)

print('Job ID: ', job_id)

while True:    
    print(IsRunning (job_id, username, password))
    if IsRunning (job_id, username, password) == 'Complete':
        break  
  
DownloadFile(data['ZipFile'], username, password)
