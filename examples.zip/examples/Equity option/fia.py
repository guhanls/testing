#-------------------------------------------------------------------------------
# Name: fia.py
# Date: 21st April 2022
# Author: Andrew Colin
# Description: Helper functions when calling Flametre Web API
# This file should always be imported into code that uses the FIA web functions
# Includes new code to check types of parameter data
# Includes versioning data to ensure new code always uses this file
#
#-------------------------------------------------------------------------------

import requests
import json
import time
import sys
import os
from requests.exceptions import ConnectionError
from requests.auth import HTTPBasicAuth

base_url = 'http://flametreeapi.com'

headers = {'Content-Type': 'application/json'}

__version__ = 2.0

#-------------------------------------------------------------------------------
# strtobool is deprecated in Python 3.10, so here is the source code instead
#-------------------------------------------------------------------------------

def strtobool(val):
    """Convert a string representation of truth to true (1) or false (0).
    True values are 'y', 'yes', 't', 'true', 'on', and '1'; false values
    are 'n', 'no', 'f', 'false', 'off', and '0'.  Raises ValueError if
    'val' is anything else.
    """
    val = val.lower()
    if val in ('y', 'yes', 't', 'true', 'on', '1'):
        return 1
    elif val in ('n', 'no', 'f', 'false', 'off', '0'):
        return 0
    else:
        raise ValueError("invalid truth value %r" % (val,))

#-------------------------------------------------------------------------------
# Ping the server and time the response
#-------------------------------------------------------------------------------

def LatencyTest():

    url = base_url
   
    t0 = time.time()
    response = requests.get(url)  
    t1 = time.time()
    total = t1-t0

    print('Pinging server at {url} took {total:.2f}s'.format(url=url, total=total))
    
#------------------------------------------------------------------------------

def GetIPAddress():
    url = base_url + '/get_my_ip'
    response = requests.get(url)  
    data = response.json()
    print(response.status_code, 'Local IP address:', data['ip'])
        
#-------------------------------------------------------------------------------
# Upload named file to user's account
#-------------------------------------------------------------------------------

def UploadFile(filename, username, password):
    
    url = base_url + '/file'    
    try:
        name = os.path.basename(filename)      
        files = {'file': (name, open(filename, 'rb'))}      
        response = requests.post(url, files=files, auth=HTTPBasicAuth(username, password) )    
        print(response.status_code, 'Uploaded', filename)
    except:
        print('Error found when uploading file', filename)
        sys.exit(1)
        
#-------------------------------------------------------------------------------
# List all files in user's account
#-------------------------------------------------------------------------------

def ListFiles(username, password):
    
    url = base_url + '/file'
    
    try:          
        response = requests.get(url, auth=HTTPBasicAuth(username, password) )  
        data = response.json()	
        
        print(response.status_code,end=' ')
        if len(data) == 0:
            print ('[No files found]')
        else:
            for f in data:
                print(f[0], end=' ')
            print('')
    except:
        print('Error found when listing files')
        sys.exit(1)

#------------------------------------------------------------------------------
# Download named file from user's account
#------------------------------------------------------------------------------

def exists(path, username, password):
    r = requests.head(path,stream=True, auth=HTTPBasicAuth(username, password)) 
    return r.status_code == requests.codes.ok

#-----------------------------------------------------------------------------

def DownloadFile (filename, username, password):
    url = base_url + '/file/' + filename

    try:   
        # Name of file to retrieve          
        response = requests.get(url, stream=True, auth=HTTPBasicAuth(username, password))         
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size = 1024):
                f.write(chunk)
        f.close()
        print(response.status_code, 'Downloaded', filename)
        return response.status_code
    except BaseException as e:
        print('Error found when downloading file', filename, str(e))
        sys.exit(1)

#-----------------------------------------------------------------------------

def DeleteFile (filename, username, password):

    url = base_url + '/file/' + filename

    try:   
        # Name of file to retrieve          
        response = requests.delete(url, auth=HTTPBasicAuth(username, password))                
        print(response.status_code, 'Deleted', filename)
        return response.status_code
    except BaseException as e:
        print('Error found when downloading file', filename, str(e))
        sys.exit(1)

#-------------------------------------------------------------------------------
# Run FIA using supplied JSON settings
#-------------------------------------------------------------------------------

def RunJson (settings, username, password):

    url = base_url + '/run-json'

    CheckBooleanTypes (settings)
    CheckIntegerTypes (settings)
    CheckRealTypes (settings)
    CheckListTypes (settings)

    try:
        headers = {'Content-Type': 'application/json'}
        response = requests.post(url, data=json.dumps(settings), headers=headers, auth=HTTPBasicAuth(username, password)) 
        print ('Posted job', response.text)		
        return response.text
    except:
        print('Error found when running program')
        sys.exit(1)

#-------------------------------------------------------------------------------
# Verify boolean settings
#-------------------------------------------------------------------------------

def CheckBooleanTypes (settings):

    BoolParams = [
     "RollDownAttribution",		
     "ConvexityAttribution",							
     "PaydownAttribution",								
     "SecuritySpecificAttribution",		
     "DTS", 															
     "ZSpreadAttribution",							
     "LeverageAttribution",								
     "AddSpreads",													
     "InteractionAttribution",								
     "PriceReturn",									
     "UseCashOffsets", 											
     "InterpolateAtTTM",								
     "RootLevelOnly",								
     "CSVreport",																
     "XLSreport",															
     "TreeMapReport",												
     "BaseToLocal",												
     "LocalToBase",													
     "BasisPoints",														
     "PortfolioBaseToLocal",						
     "PortfolioLocalToBase", 							
     "BenchmarkBaseToLocal", 							
     "BenchmarkLocalToBase",							
     "LookThrough",													
     "SummaryAttributionReport",				
     "InteractiveAttributionReport",			
     "PortfolioRiskNumberReport",			
     "SecurityRiskNumberReport",				
     "SecurityAttributionReport", 				
     "MaturityExposureReport",						
     "DurationExposureReport",						
     "DateRiskReport",												
     "SQLDataReport",												
     "ExPostRiskReport",								
     "CurveReport",														
     "StressReport",												
     "SortDescending",											
     "TotalsAtTop",														
     "FileHeaders",													
     "HedgedReturns",													
     "NormalisedStockSelection",					
     "Silent",																
     "ShowSecurityID",								
     "ShowSecurityAA",											
     "ShowRiskType",													
     "KarnoskySinger",		
    ]
	
    for key in BoolParams:        
        v = settings.get(key)
        if v is not None:      
            try:      
                value = bool(strtobool(v))
            except:
                print ('Setting \'{key}\' takes a boolean value, but the supplied value \'{v}\' could not be converted to boolean'.format(key=key, v=v))
                sys.exit(1)
           
#-------------------------------------------------------------------------------
# Verify integer settings
#-------------------------------------------------------------------------------		   
		   
def CheckIntegerTypes (settings):

    IntParams = ["BatchID", "n_cores", "ndp"]
	
    for key in IntParams:        
        v = settings.get(key)
        if v is not None:      
            try:      
                value = int(v)
            except:
                print ('Setting \'{key}\' takes an integer value, but the supplied value \'{v}\' could not be converted to integer'.format(key=key, v=v))
                sys.exit(1)		   
		   

#-------------------------------------------------------------------------------
# Verify real settings
#-------------------------------------------------------------------------------		   
		   
def CheckRealTypes (settings):

    RealParams = ["LowerTwistMaturity", "UpperTwistMaturity", "ShiftMaturity", "HedgeRatio"]
	
    for key in RealParams:        
        v = settings.get(key)
        if v is not None:      
            try:      
                value = float(v)
            except:
                print ('Setting \'{key}\' takes a real value, but the supplied value \'{v}\' could not be converted to real'.format(key=key, v=v))
                sys.exit(1)		   
		   
#-------------------------------------------------------------------------------
# Verify list settings
#-------------------------------------------------------------------------------		   
		   
def CheckListTypes (settings):

    ListParams = ["ReportSectors"]
	
    for key in ListParams:        
        v = settings.get(key)
        if v is not None and v != '':          
            if not isinstance(v, list):           
                print ('Setting \'{key}\' must be a list (in square brackets), but the supplied value \'{v}\' could not be converted to a list. \
                    \nExample 1: ["Classification, Security"] \
                    \nExample 2: ["Classification, Security", "Credit","Duration"]'.format(key=key, v=v))
                sys.exit(1)		   
		   
#-------------------------------------------------------------------------------
# Get queue
#-------------------------------------------------------------------------------

def GetQueue (username, password):
    
    url = base_url + '/status'

    try:
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, auth=HTTPBasicAuth(username, password) )
        print(response.status_code, response.text)                
    except:
        print('Error found when running program')
        sys.exit(1)

#-------------------------------------------------------------------------------
# Get queue
#-------------------------------------------------------------------------------

def GetQueueLength (username, password):
    
    url = base_url + '/qlen'

    try:
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, auth=HTTPBasicAuth(username, password) )
        print(response.status_code, response.text)                
    except:
        print('Error found when running program')
        sys.exit(1)

#-------------------------------------------------------------------------------
# Purge queue
#-------------------------------------------------------------------------------

def PurgeQueue (username, password):
    
    url = base_url + '/purge'
    print (url)
    try:
        headers = {'Content-Type': 'application/json'}
        response = requests.put(url, auth=HTTPBasicAuth(username, password) )
        print(response.status_code, response.text)                
    except:
        print('Error found when running program')
        sys.exit(1)

#-------------------------------------------------------------------------------
# Is named job running?
#-------------------------------------------------------------------------------

def IsRunning (id, username, password):
    
    url = base_url + '/status/' + id

    try:
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, auth=HTTPBasicAuth(username, password) )
        j = json.loads(response.text)
        print(response.status_code, id, j['status'])                
        return j['status']
    except:
        print('Error found when running program')
        sys.exit(1)

#-------------------------------------------------------------------------------
# List all users
#-------------------------------------------------------------------------------

def ListUsers(mpassword):
    
    url = base_url + '/user/all'
   
    try:    
        data = {}
        data['master_password'] = mpassword
        json_data = json.dumps(data)                 
        response = requests.get(url, data=json_data, headers=headers)         
        print(response.status_code, response.text)
    except:
        print('Error found when listing users')
        sys.exit(1)

#-------------------------------------------------------------------------------
# Create new user  
#-------------------------------------------------------------------------------
      
def CreateUser(username, password, master_password):

    url = base_url + '/user'
    data = {}
    data['username'] = username
    data['password'] = password
    data['master_password'] = 'password'
    json_data = json.dumps(data)
    response = requests.post(url, data=json_data, headers=headers) 
    print(response.status_code, response.text)             
    if response.status_code == 201:
        return True
    else:
        return False

#-------------------------------------------------------------------------------
# Delete user  
#-------------------------------------------------------------------------------
      
def DeleteUser(username, master_password):

    url = base_url + '/user'
    print ('Deleting user ', username)
    data = {}
    data['username'] = username
    data['master_password'] = master_password
    json_data = json.dumps(data)
    response = requests.delete(url, data=json_data, headers=headers)                         
    print(response.status_code, response.text)      
    if response.status_code == 200:
        return True
    else:
        return False

#-------------------------------------------------------------------------------
# Get login token
#-------------------------------------------------------------------------------

def GetToken(username, password):
    url = base_url + '/token'
    response = requests.get( url, auth=HTTPBasicAuth(username, password) )                       
    print (response.text)
    print (response.status_code)

    j = json.loads(response.text)
    token = j['token']

    return token

#-------------------------------------------------------------------------------
# Finished jobs
#-------------------------------------------------------------------------------

def FinishedJobs (username, password):
    
    url = base_url + '/finished'
    print (url)
    try:
        headers = {'Content-Type': 'application/json'}
        response = requests.get(url, auth=HTTPBasicAuth(username, password) )
        print('Finished', response.status_code, response.text)                
    except:
        print('Error found when running program')
        sys.exit(1)
