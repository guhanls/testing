#------------------------------------------------------------------------------
#
# File: equity_option.py
#
# Author: Andrew Colin
#
# Description: Simple demo to show how to upload files, run FIA, and download
# results.
#
#------------------------------------------------------------------------------

from fia import *

username = 'NT'
password = 'ff7#7U'

data = {
    "PortfolioFile"                 : "equity_option_p.csv",
    "SecurityFile"                  : "equity_option_s.csv",
    "DateFormat"                    : "%Y-%b-%d",
    "CarryDecomposition"            : "NONE",
    "SovereignCurveDecomposition"   : "NONE",
    "BatchID"			            : "0",
    "SummaryAttributionReport"      : "true",
    "InteractiveAttributionReport"  : "true",
    "CSVreport"                     : "false",
    "XLSreport"                     : "true",
    "SmoothingModel"                : "Carino",
    "SingleExcelReportFile"         : "equity_option",
    "FileHeaders"                   : "true",    
    "ZipFile"                       : "equity_option.zip"
    
}

print ('Pinging the server to test latency')
LatencyTest()

GetIPAddress()

ListFiles(username, password)

DeleteFile("*", username, password)

# Upload files only once
UploadFile (data['PortfolioFile'],    username, password)
UploadFile (data['SecurityFile'],     username, password)

ListFiles(username, password)

# Run FIA using these parameters and files in filestore
print('Running FIA using JSON settings')
job_id = RunJson (data, username, password)

print('Job ID: ', job_id)

while True:    
    print(IsRunning (job_id, username, password))
    if IsRunning (job_id, username, password) == 'Complete':
        break  
  
DownloadFile(data['ZipFile'], username, password)
