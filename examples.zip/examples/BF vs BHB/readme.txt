This directory contains sample data for a very simple single level Brinson analysis. Aim is to show the difference between Brinson-Fachler and Brinson-Hood-Beebower attribution. To change from one to the other, set the BrinsonModel switch to BF or BHB (other values are disallowed)

Raw data was taken from section 3.4, Chapter 3, 'Mastering attribution in finance', Andrew Colin.

The calculation algorithm used is described in the attached white paper 'Implementing hybrid attribution'.